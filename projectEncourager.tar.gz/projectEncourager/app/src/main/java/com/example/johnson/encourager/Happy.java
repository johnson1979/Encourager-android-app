package com.example.johnson.encourager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Happy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_happy);
    }
    public void onClickBack(View view){
        Intent intent=new Intent(this,Moods.class);
        startActivity(intent);
    }
}
